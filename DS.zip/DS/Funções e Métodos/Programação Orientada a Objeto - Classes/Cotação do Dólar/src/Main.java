import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Dolar grana = new Dolar();

        System.out.print("Informe quantos Dólares -> ");
        grana.dinheiro = sc.nextInt();

        System.out.print("Informe a cotação do Dolar -> ");
        grana.cotacao = sc.nextInt();

        System.out.print("A quantidade de Dinheiro disponível é de -> " +grana.conversao());
        sc.close();
    }
}