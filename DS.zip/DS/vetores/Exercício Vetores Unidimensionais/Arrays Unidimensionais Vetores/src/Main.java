public class Main {
    public static void main(String[] args) {
        int p[] = {10,20,30,40,50,60};
        System.out.println(p[1]);
        System.out.println(p[1+3]);
        System.out.println(p[p[5-2]-38]);
        System.out.println(p[2]*p[4]);
        System.out.println(p[3]%p[1]);
        }
    }