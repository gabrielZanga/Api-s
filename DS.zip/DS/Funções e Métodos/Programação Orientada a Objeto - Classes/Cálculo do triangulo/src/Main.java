import java.text.DecimalFormat;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        CalcTriangulo calc = new CalcTriangulo();

        System.out.print("Qual o valor da base do triângulo? ");
        calc.base = sc.nextInt();

        System.out.print("Qual a altura do triângulo? ");
        calc.altura = sc.nextInt();

        System.out.print("O valor da área do triangulo é de -> " +calc.areaTriangulo());

        sc.close();
    }
}