package com.br.gabrielvieira.ApiMunicipios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiMunicipiosApplicationTests {

	@Test
	void contextLoads() {
	}

}
