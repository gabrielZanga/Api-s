public class CalcularSoma {

    public int a;
    public int b;
    public int c;

    public int somaValores(){
        return a + b + c;
    }
}
