public class CalcTriangulo {

    public int base;
    public int altura;

    public int areaTriangulo(){
        return (base*altura)/2;
    }
}
