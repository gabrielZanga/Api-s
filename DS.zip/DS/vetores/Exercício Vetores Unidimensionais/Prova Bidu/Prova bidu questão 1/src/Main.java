import java.text.DecimalFormat;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        DecimalFormat df = new DecimalFormat();
        Scanner sc = new Scanner(System.in);

        int x[][] = new int[5][5];
        int c[][] = new int[5][5];

        for (int i = 0; i < 5; i++){
            for (int j = 0; j < 5; j++){
                System.out.print("Matriz x[" + i + "][" + j + "]= ");
                x[i][j] = sc.nextInt();

                System.out.println(" ");
            }
        }
        for(int i = 0; i < 5; i++){
            for (int j = 0; j < 5; j++){
                c[i][j] = x[i][j] * x[i][j] * x[i][j];
            }
        }
        for (int j = 0; j < 5; j++){
            System.out.println("Os elementos da Matriz do meio é de => " +c[3][j]);
        }
        sc.close();
    }
}