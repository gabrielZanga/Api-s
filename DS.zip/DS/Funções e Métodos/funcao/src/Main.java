import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int a, b, soma;

        System.out.print("Informe o primeiro valor => ");
        a = sc.nextInt();

        System.out.print("Informe o segundo valor => ");
        b = sc.nextInt();

        soma = calcularSoma(a, b);

        imprimirResultado(soma);

        sc.close();
    }

    public static int calcularSoma(int num1, int num2) {
        int aux = num1 + num2;
        return aux;
    }

    public static void imprimirResultado(int resultado){
        System.out.print("A soma é de: " + resultado);
    }
}