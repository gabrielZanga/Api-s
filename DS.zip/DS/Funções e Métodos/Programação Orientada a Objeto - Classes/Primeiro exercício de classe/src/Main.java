import java.text.DecimalFormat;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int soma;

        CalcularSoma calc, calc1;
        calc = new CalcularSoma(); //Instanciação da classe CalcularSoma

        System.out.print("Informe o valor de A => ");
        calc.a = sc.nextInt();
        System.out.print("Informe o valor de B => ");
        calc.b = sc.nextInt();
        System.out.print("Informe o valor de C => ");
        calc.c = sc.nextInt();

        soma = calc.somaValores();
        System.out.print("A soma é de " + soma);

        calc1 = new CalcularSoma();

        System.out.print("Informe o valor de D => ");
        calc1.a = sc.nextInt();
        System.out.print("Informe o valor de E => ");
        calc1.b = sc.nextInt();
        System.out.print("Informe o valor de F => ");
        calc1.c = sc.nextInt();

        soma = calc1.somaValores();
        System.out.print("A soma é de " + soma);

        sc.close();
    }
}