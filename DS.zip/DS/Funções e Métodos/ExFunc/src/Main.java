import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int maior, a1, a2, a3;

        System.out.print("Informe o primeiro número => ");
        a1 = sc.nextInt();

        System.out.print("Informe o segundo número => ");
        a2 = sc.nextInt();

        System.out.print("Informe o terceiro número => ");
        a3 = sc.nextInt();

        maior = comparacaoNum(a1, a2, a3);
        sc.close();

        System.out.print("O número maior é => " +maior);
    }

    public static int comparacaoNum(int num1, int num2, int num3) {
        int maior = 0;
        if (num1 == maior) {
            if (num2 > num1) {
                maior = num2;
            }
        }

        if (num3 > num2) {
            maior = num3;
        }
        return  maior;
    }
}
