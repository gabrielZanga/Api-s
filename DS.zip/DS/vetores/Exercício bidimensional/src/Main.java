import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int x [][] = new int[3][3];

        for (int i = 0; i <= 2; i++){
            for (int j = 0; j <= 2; j++){
                System.out.print("x["+i+"]["+j+"]= ");
                x[i][j] = sc.nextInt();

                System.out.println(" ");
            }
        }
        for (int i = 0; i <= 2; i++){
            for (int j = 0; j <= 2; j++){
                System.out.print(" "+x[i][j]);
            }
            System.out.println(" ");
        }
        sc.close();
    }
}