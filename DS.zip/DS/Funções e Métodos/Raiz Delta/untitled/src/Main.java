import java.text.DecimalFormat;
import java.util.Scanner;

public class Main {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        double a, b, c, delta;

        System.out.print("Informe o valor de A => ");
        a = sc.nextDouble();

        System.out.print("Informe o valor de B => ");
        b = sc.nextDouble();

        System.out.print("Informe o valor de C => ");
        c = sc.nextDouble();

        delta = calcularDelta(a, b, c);

        verificaDelta(delta, a, b);

        sc.close();
    }

    public static double calcularDelta(double a, double b, double c){

        double aux = Math.pow(b,2) - (4 * a * c);
        return aux;
    }

    public static void verificaDelta(double delta, double a, double b){
        DecimalFormat df = new DecimalFormat("##0.0");

        double x1, x2;
        if (delta >= 0){
            x1 = calcularRaiz1(delta, a, b);
            x2 = calcularRaiz2(delta, a, b);

            imprimirTxt("X1 => " +df.format(x1));
            imprimirTxt("X2 => " +df.format(x2));
        }

        else{
            imprimirTxt("Não existem Raízes Reais!!!");
        }
    }

    public static double calcularRaiz1(double delta, double a, double b){
        return (-b + Math.sqrt(delta))/(2 * a);
    }

    public static double calcularRaiz2(double delta, double a, double b){
        return (-b - Math.sqrt(delta))/(2 * a);
    }

    public static void imprimirTxt(String msg){
        System.out.println(msg);
    }
}
