import java.util.Scanner;
import java.util.Arrays;
public class Main {
    public static void main(String[] args) {
        //Elabore um algoritimo onde o usuário//
        //informa um vetor "V" com 10 posições e...//
        //calcule a soma dos valores do vetor par//
        // e a soma dos valores do vetor com indíce ímpar.//

        Scanner sc = new Scanner(System.in);
        int[] vet = new int[10];
        int somapar = 0, somaimpar = 0;

        for (int i = 0; i<=9; i++){
        System.out.println("Insira os valores v["+i+"]=");
        vet[i] = sc.nextInt();
        }

        for (int i = 0; i<=9; i++){

            if (vet[i] %2 ==0){
                somapar = somapar +vet[i];
            }
            if (i % 2 != 0){
                somaimpar = somaimpar +vet[i];
            }
        }
        System.out.println("A soma dos números pares é de: " +somapar);
        System.out.println("A soma dos números  com índice impar é de: " +somaimpar);
        sc.close();
    }
}