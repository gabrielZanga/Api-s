public class Dolar {

    public int dinheiro;
    public int cotacao;

    public double conversao(){
        return dinheiro*cotacao;
    }
}
