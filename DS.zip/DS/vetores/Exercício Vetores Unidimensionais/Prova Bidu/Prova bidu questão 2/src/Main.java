import java.text.DecimalFormat;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        DecimalFormat df = new DecimalFormat("###,#0.0");
        Scanner sc = new Scanner(System.in);

        double x[][] = new double[4][3];
        int linha;
        int coluna;

        for (int i = 0; i < 4; i++){
            for (int j = 0; j < 3; j++){
                System.out.print("Matriz x[" + i + "][" + j + "]= ");
                x[i][j] = sc.nextDouble();

                System.out.println(" ");
            }
        }
        System.out.print("Informe o número da linha C => " );
        linha = sc.nextInt();

        System.out.println(" ");

        System.out.print("Informe o número da coluna C => " );
        coluna = sc.nextInt();

        System.out.println(" ");

        System.out.print("O resultado é de => " + df.format((x[linha][coluna])));

        sc.close();
    }
}
