import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        //faça um algorítimo para ler uma matriz 2x3 real e depois
        //gerar e imprimir sua transposta (matriz 3x2 equivalente);

        Scanner sc = new Scanner(System.in);
        int m[][] = new int[2][3];
        int transp[][] = new int[3][2];

        for (int i = 0; i <= 1; i++) {
            for (int j = 0; j <= 2; j++) {
                System.out.print("Matriz m[" + i + "][" + j + "]= ");
                m[i][j] = sc.nextInt();

                System.out.println(" ");
            }
        }
        for (int i = 0; i <= 2; i++){
            for (int j = 0; j <= 1; j++ ){
                transp[i][j] = m[j][i];
            }
        }
        for (int i = 0; i <= 2; i++) {
            for (int j = 0; j <= 1; j++) {
                System.out.print("Matriz transp[" + i + "][" + j + "]= " +transp[i][j] + "   ");
            }
            System.out.println("  ");
        }
        sc.close();
    }
}