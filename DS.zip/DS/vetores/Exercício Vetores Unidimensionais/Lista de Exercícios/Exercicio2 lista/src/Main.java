import java.text.DecimalFormat;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        //Elabore um algorítimo onde o usuário vai informar 10 números em um vetor
        //e vai calcular a soma dos números pares, a soma dos números impares e
        //a média dos elementos do vetor.

        DecimalFormat df = new DecimalFormat("###,##0.0");
        Scanner sc = new Scanner(System.in);
        int x [] = new int[10];
        int somapar = 0, somaimpar = 0;
        double media = 0;

        for (int i = 0; i <= 9; i++){
            System.out.print("Matriz x[" + i + "]= ");
            x[i] = sc.nextInt();

            System.out.println(" ");
        }
        for (int i = 0; i <= 9; i++){
            if (x[i] % 2 == 0){
                somapar += x[i];
            }
            else{
                somaimpar += x[i]
            }
        }
        media = (double) (somapar + somaimpar)/10;

        System.out.println("A soma dos números pares é de: " +somapar);
        System.out.println("A soma dos números ímpares é de: " +somaimpar);
        System.out.println("O valor da média é de => " + df.format(media));
        sc.close();
    }
}