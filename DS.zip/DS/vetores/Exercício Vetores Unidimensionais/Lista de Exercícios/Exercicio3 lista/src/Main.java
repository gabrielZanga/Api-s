import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        //Escreva um algorítimo que lê uma matriz M(5,5) e calcule as somas:
        //a) da linha 4 de M;
        //b) da coluna 2 de M;
        //c) da diagonal principal;
        //d) da diagonal secundária;
        //e) de todos os elementos da matriz;
        //f) Escreva estas somas e a matriz.

        Scanner sc = new Scanner(System.in);
        double m[][] = new double[5][5];
        int soma = 0;

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print("Matriz m[" + i + "][" + j + "]= ");
                m[i][j] = sc.nextDouble();

                System.out.println(" ");
            }
        }
        for (int j = 0; j < 5; j++) {
            soma += m[4][j];
        }
        System.out.println("A soma da linha 4 é de: " + soma);
        soma = 0;

        for (int i = 0; i < 5; i++) {
            soma += m[i][2];
        }
        System.out.println("A soma da coluna 2 é de: " + soma);
        soma = 0;

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (i == j) {
                    soma += m[i][j];
                }
            }
        }
        System.out.println("A soma da diagonal principal é de: " + soma);
        soma = 0;

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (i + j == m.length - 1){
                    soma += m[i][j];
                }
            }
        }
        System.out.println("A soma da diagonal secundária é de: " +soma);
    }
}


