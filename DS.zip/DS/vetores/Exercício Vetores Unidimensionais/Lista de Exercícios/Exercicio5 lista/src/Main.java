import java.text.DecimalFormat;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        //Ler uma matriz 4x3 real e imprimir a soma dos elementos
        //de uma linha l fornecida pelo usuário.

        DecimalFormat df = new DecimalFormat("###,##0.0");
        Scanner sc = new Scanner(System.in);

        int x [][] = new int[4][3];
        int soma = 0;
        int resp;

        for (int i = 0; i <= 3; i++){
            for (int j = 0; j <= 2; j++){
                System.out.print("Matriz x[" + i + "][" + j + "]= ");
                x[i][j] = sc.nextInt();
            }
            System.out.println(" ");
        }
        System.out.print("Informe o número da linha l => ");
        resp = sc.nextInt();

        switch (resp){
            case 0:
                for (int j = 0; j <= 2; j++){
                    soma = soma +x[0][j];
                }
                System.out.print("A soma dos números da linha 0 são de => " +soma);
                break;

            case 1:
                for (int j = 0; j <= 2; j++){
                    soma = soma +x[1][j];
                }
                System.out.print("A soma doss números da linha 1 são de => " +soma);
                break;

            case 2:
                for (int j = 0; j <= 2; j++){
                    soma = soma +x[2][j];
                }
                System.out.print("A soma dos números da linha 2 são de => " +soma);
                break;

            case 3:
                for (int j = 0; j <= 2; j++){
                    soma = soma +x[3][j];
                }
                System.out.print("A soma dos números da linha 3 são de => " +soma);
                break;
        }
        sc.close();
    }
}