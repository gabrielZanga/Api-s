import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int math[][] = new int [4][4];
        int sum = 0;

        for (int i = 0; i <= 3; i++){
            for (int j = 0; j <= 3; j++){
                System.out.print("math["+i+"]["+j+"]= ");
                math[i][j] = sc.nextInt();

                System.out.println(" ");
            }
        }
        for (int i = 0; i <= 3; i++){
            for (int j = 0; j <= 3; j++) {
                if (i+j == 3) {
                    sum += math[i][j];
                }
                System.out.print(" " + math[i][j]);
            }
            System.out.println(" ");
        }
        System.out.println("Soma da diagonal secundária => " +sum);
        sc.close();
    }
}