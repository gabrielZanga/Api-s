import java.text.DecimalFormat;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        //Faça um algorítimo onde o usuário informa duas matrizes
        //x e y de dimensão 4x2 e efetue a multiplicação dos
        //elementos da matriz caso os elementos matrizes x e y sejam par,
        // caso contrário dividir. Exibir o resultado na matriz z.

        DecimalFormat df = new DecimalFormat("###,##0.0");
        Scanner sc = new Scanner(System.in);
        int x[][] = new int[4][2];
        int y[][] = new int[4][2];
        double z[][] = new double[4][2];

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print("Matriz x[" + i + "][" + j + "]= ");
                x[i][j] = sc.nextInt();

                System.out.println(" ");
            }
        }
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print("Matriz y[" + i + "][" + j + "]= ");
                y[i][j] = sc.nextInt();

                System.out.println(" ");
            }
        }
        System.out.println(" ");

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 2; j++) {

                if ((x[i][j] % 2 == 0) && (y[i][j] % 2 == 0)) {
                    z[i][j] = x[i][j] * y[i][j];
                }

                else {
                    z[i][j] = (double) x[i][j] / y[i][j];
                }
            }
        }
        for (int i = 0; i < 4; i++){
            for (int j = 0; j < 2; j++){
                System.out.println("Matriz z[" + i +"][" + j +"]= " +df.format(+z[i][j]));

                System.out.println(" ");
            }
        }
        sc.close();
    }
}