import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Elabore um algoritimo onde o usuário informe
        //os valores de uma matriz "math" de dimensão 3x3 e calcule:
        //1) A soma dos elementos da diagonal principal;
        //2) A multiplicação dos elementos da diagonal secundária;

        Scanner sc = new Scanner(System.in);
        int math[][] = new int [3][3];
        int sum = 0;
        int mult = 0;

        for (int i = 0; i <= 2; i++){
            for (int j = 0; j <= 2; j++){
                System.out.print("math["+i+"]["+j+"]= ");
                math[i][j] = sc.nextInt();

                System.out.println(" ");
            }
        }
        for (int i = 0; i <= 2; i++){
            for (int j = 0; j <= 2; j++){
                if (i==j) {
                    sum += math[i][j];
                }
                System.out.print(" "+math[i][j]);
            }
            System.out.println(" ");
        }
        sc.close();
    }
}